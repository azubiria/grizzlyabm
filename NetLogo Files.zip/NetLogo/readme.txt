This folder contains annotated model code and all necessary input data. The model is meant to be implemented in NetLogo 6.1.1*
*Wilensky, U. 1999. NetLogo. http://ccl.northwestern.edu/netlogo/. 

If you would like to use part of this code we ask that you please reference our work:
Zubiria Perez, A., Bone, C., & Stenhouse, G. (2021). Simulating multi-scale movement decision-making and learning 
in a large carnivore using agent-based modelling. Ecological Modelling, 452(September 2020), 109568. 
https://doi.org/10.1016/j.ecolmodel.2021.109568

Any questions about the code can be addressed to Alejandra Zubiria Perez (aleja.zubiria@gmail.com)

;;; MODEL SETUP NOTES ;;;
Given the size of the world used in this model, you will have to increase the RAM available for Netlogo to at least 6000
See: https://ccl.northwestern.edu/netlogo/docs/faq.html#how-big-can-my-model-be-how-many-turtles-patches-procedures-buttons-and-so-on-can-my-model-contain

In order to run the code successfully you must indicate whether memory is active or not.
Main setup only needs to be completed once, but the lanscape should be set up before each new simulation
Run-type is only used to distinguish between model outputs (memory vs. no memory)
Most parameters are constant throughout the simualtions or changes are embedded within the code